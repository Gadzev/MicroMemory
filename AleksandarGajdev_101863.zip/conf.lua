function love.conf(t)
	t.title = "Love Memory"
	t.window.width = 1024	
	t.window.height = 768
end